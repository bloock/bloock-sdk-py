class HttpData():
    ''' API key storage object.'''

    def __init__(self, api_key='api_key'):
        self.api_key = api_key
