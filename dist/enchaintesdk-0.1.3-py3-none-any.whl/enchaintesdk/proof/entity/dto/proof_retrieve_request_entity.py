class ProofRetrieveRequest:
    def __init__(self, messages: [str]):
        self.messages = messages
