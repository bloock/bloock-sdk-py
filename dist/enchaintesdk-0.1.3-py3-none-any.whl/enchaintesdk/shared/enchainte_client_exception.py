class EnchainteSDKException(Exception):
    """Base class exception for Enchainté SDK."""
    pass
