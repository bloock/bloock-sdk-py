class Network:
    def __init__(self, name: str, state: str, tx_hash: str):
        self.name = name
        self.state = state
        self.tx_hash = tx_hash
